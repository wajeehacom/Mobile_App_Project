package com.example.financepal

data class UserTransactionReport
    (
     val totalIncome: Double,
     val totalExpense: Double
            )